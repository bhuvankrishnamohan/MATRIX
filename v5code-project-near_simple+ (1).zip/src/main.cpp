/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    21, 7, 1, 5     
// Controller1          controller                    
// intake               motor         2               
// roller               motor         8               
// cata                 motor         14              
// hopper               motor         19              
// expansion            digital_out   B               
// touch                bumper        H               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

// A global instance of competition
competition Competition;

// define your global instances of motors and other devices here

/*---------------------------------------------------------------------------*/
/*                          Pre-Autonomous Functions                         */
/*                                                                           */
/*  You may want to perform some actions before the competition starts.      */
/*  Do them in the following function.  You must return from this function   */
/*  or the autonomous and usercontrol tasks will not be started.  This       */
/*  function is only called once after the V5 has been powered on and        */
/*  not every time that the robot is disabled.                               */
/*---------------------------------------------------------------------------*/

void pre_auton(void) {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  // All activities that occur before the competition starts
  // Example: clearing encoders, setting servo positions, ...
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              Autonomous Task                              */
/*                                                                           */
/*  This task is used to control your robot during the autonomous phase of   */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void autonomous(void) {
  // ..........................................................................
  // Insert autonomous user code here.
  // ..........................................................................
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*                              User Control Task                            */
/*                                                                           */
/*  This task is used to control your robot during the user control phase of */
/*  a VEX Competition.                                                       */
/*                                                                           */
/*  You must modify the code to add your own robot specific commands here.   */
/*---------------------------------------------------------------------------*/

void usercontrol(void) {
  // User control code here, inside the loop
  while (1) {
//setting velocities
    // This is the main execution loop for the user control program.
    // Each time through the loop your program should update motor + servo
    // values based on feedback from the joysticks.
    intake.spin(vex::directionType::fwd, Controller1.ButtonR2.pressing()*127 -Controller1.ButtonR1.pressing()*127, vex::velocityUnits::pct);

    roller.setVelocity(100, percent);

    hopper.setVelocity(40, rpm);

    if (Controller1.ButtonL1.pressing()){
      roller.spin(forward);
    }

    if (Controller1.ButtonB.pressing()){
      hopper.setVelocity(10, percent);
      hopper.spinFor(forward, 119, degrees);
    }

    if (Controller1.ButtonY.pressing()){
      hopper.setVelocity(10, percent);
      hopper.spinFor(reverse, 119, degrees);
    }

    if (Controller1.ButtonL2.pressing()){
      roller.stop();
    }

    if (Controller1.ButtonLeft.pressing()){
      hopper.stop();
    }
    if (Controller1.ButtonDown.pressing()){
     if (touch.pressing() == true) {
      cata.stop();
     }
     else if (touch.pressing() == false){
       cata.spin(forward);
     }
    }

    if (Controller1.ButtonA.pressing()){
      cata.spinFor(forward, 1800, degrees);
    }

    

    // ........................................................................
    // Insert user code here. This is where you use the joystick values to
    // update your motors, etc.
    // ........................................................................

    wait(20, msec); // Sleep the task for a short amount of time to
                    // prevent wasted resources.
  }
}

//
// Main will set up the competition functions and callbacks.
//
int main() {
  // Set up callbacks for autonomous and driver control periods.
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);

  // Run the pre-autonomous function.
  pre_auton();

  // Prevent main from exiting with an infinite loop.
  while (true) {
    wait(100, msec);
  }
}
